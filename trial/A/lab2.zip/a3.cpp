#include <iostream>

using namespace std;


double a, b;
int main () {
	cin >> a >> b;
	if (a < b)
		cout << a << " is lesser than " << b << endl;
	else if (a > b)	
		cout << a << " is greater than " << b << endl;
	else
		cout << "Two numbers are equal";
}


