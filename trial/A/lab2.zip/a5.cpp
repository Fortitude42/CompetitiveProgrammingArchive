#include <iostream>

using namespace std;


string s;
int main () {
	cin >> s;
	for (int i = 0; i < s.size(); ++i)
		if (s[i] != s[s.size() - 1 - i]) {
			cout << "Not palindrome";
			return 0;
		}

	cout << "Palindrome";
}
	


