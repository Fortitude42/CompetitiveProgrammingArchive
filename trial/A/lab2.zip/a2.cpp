#include <iostream>

using namespace std;

double r1, r2;
int type;

int main () {
	cin >> r1 >> r2 >> type;
	if (type == 1)
		cout << r1 + r2 << endl;
	else
		cout << (r1*r2)	/ (r1 + r2) << endl;
}


