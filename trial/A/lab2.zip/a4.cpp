#include <iostream>

using namespace std;

int a, b;

int main () {
	cin >> a >> b;
	puts(a % b == 0 ? "Yes" : "No");
}
	


