#include <iostream>

using namespace std;

int a, b;

int main () {
	cin >> a >> b;
	for (int i = 0; i <= b; ++i) {
		int p = 1;
		for (int j = 0; j < i; ++j)
			p *= a;
		cout << i << ' ' << p << endl;
	}
}


