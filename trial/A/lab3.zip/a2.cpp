#include <iostream>

using namespace std;

int cnt, sum, x;

int main () {
	while (1) {
		cin >> x;
		if (!x)
			break;
		++cnt;
		sum += x;
	}

	cout << cnt << endl;
	cout << (!cnt ? 0 : (sum + 0.0) / cnt) << endl;
}


