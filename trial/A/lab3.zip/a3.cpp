#include <iostream>

using namespace std;

int mx, x;
bool fst = 1;

int main () {
	while (1) {
		cin >> x;
		if (!x)
			break;
		if (fst) {
			mx = x;
			fst = 0;
		} else
			mx = max(mx, x);
	}

	cout << mx << endl;

}


