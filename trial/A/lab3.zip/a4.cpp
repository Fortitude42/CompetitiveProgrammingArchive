#include <iostream>

using namespace std;

int n;

int main () {
	cin >> n;
	int sum = 0;
	for (int i = 1, j = 0; j < n; ++j, i += 2)
		sum += i;
	cout << sum << endl;
}


