#include <bits/stdc++.h>

using namespace std;

int n;

int main () {
	cin >> n;
	for (int i = 1; i <= n; ++i)
		cout << i << ' ' << i*i << endl;
}


