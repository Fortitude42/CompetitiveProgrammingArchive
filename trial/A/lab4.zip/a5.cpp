#include <iostream>

using namespace std;

string s;

int main () {
	cin >> s;
	bool ok = 1;
	for (int i = 0; i < s.size(); ++i)
		if (s[i] != s[s.size() - 1 - i])
			ok = 0;

	puts(ok ? "Yes" : "No");
}


