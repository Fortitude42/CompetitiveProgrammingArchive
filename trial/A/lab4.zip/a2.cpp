#include <iostream>

using namespace std;

int n;

int main () {
	cin >> n;
	int a[n], sum = 0;
	for (int i = 0; i < n; ++i) {
		cin >> a[i];
		sum += a[i];
	}

	cout << "Total: " << sum << endl;
	cout << "Average: " << (sum + 0.0) / n << endl;
}


