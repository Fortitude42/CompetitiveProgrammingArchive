#include <iostream>

using namespace std;

int n;

int main () {
	cin >> n;
	int a[n]	;
	for (int i = 0; i < n; ++i) 
		cin >> a[i];

	int mn = a[0], mx = a[0];
	for (int i = 1; i < n; ++i) {
		mn = min(mn, a[i]);      
		mx = max(mx, a[i]);
	}

	int cnt = 0, sum = 0;
	for (int i = 0; i < n; ++i) 
		if (a[i] != mn && a[i] != mx) {
			++cnt;
			sum += a[i];
		}

	cout << "Total: " << sum << endl;
	cout << "Average: " << (!cnt ? 0 : (sum + 0.0) / cnt) << endl;
}


