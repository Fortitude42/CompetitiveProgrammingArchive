#include <bits/stdc++.h>

using namespace std;

double a, b;

int main () {
	cin >> a >> b;
	cout << a - b << endl;
}


