#include <iostream>

using namespace std;

int a, b, h;

int main () {
	cin >> a >> b >> h;
	cout << (a + b) * 1.0 * h / 2;
}
	


