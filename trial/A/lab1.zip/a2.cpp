#include <iostream>

using namespace std;

int x;

int main () {
	cin >> x;
	cout << 4*x*x - 2*x - 4 << endl;
}


