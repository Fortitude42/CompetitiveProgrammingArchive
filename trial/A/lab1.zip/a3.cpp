#include <iostream>

using namespace std;


double a;
int main () {
	cin >> a;
	cout << a / 1.60934 << " miles" << endl;
}


